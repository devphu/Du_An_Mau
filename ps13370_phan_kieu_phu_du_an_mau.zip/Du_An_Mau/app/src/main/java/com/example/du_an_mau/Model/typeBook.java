package com.example.du_an_mau.Model;

public class typeBook {
    public String codeType;
    public int amount;

    public typeBook(String codeType, int amount) {
        this.codeType = codeType;
        this.amount = amount;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
