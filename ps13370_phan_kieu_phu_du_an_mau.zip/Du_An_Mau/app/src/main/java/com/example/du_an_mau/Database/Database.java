package com.example.du_an_mau.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    public static final String Database_name = "book";
    public static final  int veson =1;
    public Database(Context context){
        super(context,Database_name,null,veson);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
//        String sql1 = "CREATE TABLE hoaDon(codeHd integer primary key autoincrement,  "
        String sql_typeBook = "CREATE TABLE typeBook(codeType text primary key,amount integer not null)";
        sqLiteDatabase.execSQL(sql_typeBook);
        sql_typeBook = "INSERT INTO typeBook(nameType,amount) VALUES('CNTT',20)";
        sqLiteDatabase.execSQL(sql_typeBook);
        sql_typeBook = "INSERT INTO typeBook(nameType,amount) VALUES('Văn Học',30)";
        sqLiteDatabase.execSQL(sql_typeBook);
        sql_typeBook = "INSERT INTO typeBook(nameType,amount) VALUES('Thiên Văn Học',40)";
        sqLiteDatabase.execSQL(sql_typeBook);
        String sql_Book ="CREATE TABLE book(codeBook integer primary key autoincrement ,nameBook text not null,priceBook integer not null,nsb text,codeType text not null references typeBook(codeType))";
        sqLiteDatabase.execSQL(sql_Book);
        sql_Book = "INSERT INTO book(StnameBook,priceBook,nsb,codeType) VALUES('Hành Lang lập trình',30000,'FPT','CNTT')";
        sqLiteDatabase.execSQL(sql_Book);
        sql_Book = "INSERT INTO book(nameBook,priceBook,nsb,codeType) VALUES('Chí Phèo',30000,'HCM','Văn Học')";
        sqLiteDatabase.execSQL(sql_Book);
        sql_Book = "INSERT INTO book(nameBook,priceBook,nsb,codeType) VALUES('Khám phá sao hỏa',20000,'HN','Thiên Văn Học')";
        sqLiteDatabase.execSQL(sql_Book);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
