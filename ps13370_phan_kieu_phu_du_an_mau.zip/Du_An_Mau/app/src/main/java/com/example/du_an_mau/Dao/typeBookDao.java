package com.example.du_an_mau.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.du_an_mau.Database.Database;
import com.example.du_an_mau.Model.Book;
import com.example.du_an_mau.Model.typeBook;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class typeBookDao {
    Database database;
    ArrayList<typeBook> arrayList;
    private SQLiteDatabase sqldatabase;
    public typeBookDao(Context context){
        Database database = new Database(context);
        sqldatabase = database.getWritableDatabase();
    }
    public ArrayList<typeBook> readAll(){
        SQLiteDatabase sqLiteDatabase;
        ArrayList<typeBook> arrayList = new ArrayList<>();
        Cursor cs = sqldatabase.rawQuery("select * from typeBook", null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            String codeType = cs.getString(0);
            int amount = cs.getInt(1);
            arrayList.add(new typeBook(codeType,amount)) ;

            cs.moveToNext();


        }
        cs.close();
        return  arrayList;
    }
    public long insert(typeBook book){
        ContentValues contentValues = new ContentValues();
        contentValues.put("codeType",book.getCodeType());
        contentValues.put("amount",book.getAmount());
       return sqldatabase.insert("typeBook",null,contentValues);

    }
    public int update(typeBook book){
        ContentValues contentValues = new ContentValues();
        contentValues.put("amount",book.getAmount());
        return   sqldatabase.update("typeBook",contentValues,"codeType=?",new String[]{
                String.valueOf(book.getAmount())
        });
    }
    public int delete(typeBook book){
        return
                sqldatabase.delete("typeBook","codeType=?",new String[]{
                String.valueOf(book.getCodeType())
        });
    }
}
